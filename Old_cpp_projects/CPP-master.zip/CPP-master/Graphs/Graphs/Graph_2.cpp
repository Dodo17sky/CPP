#include "stdafx.h"
#include "Graph_2.h"
#include <fstream>
#include <iomanip>

void Graph_2::dijkstra(int src)
{
	/* If isFinal[i] = true, means that shortest distance from src to vertex i has been found */
	std::vector<bool> isFinal(V, false);
	uint32 node = src;
	
	/* shortest distance from src to itself is 0 */
	minDistance[node] = 0;

	for (int v = 0; v < V; v++) {
		if (v == src)
			continue;

		node = getShortestPathNode(isFinal);
		isFinal[node] = true;

		for (AdjacentNode a : graph[node]) {
			int c = a.child;
			if (isFinal[c] == false && minDistance[c] > minDistance[node] + a.weight) {
				minDistance[c] = minDistance[node] + a.weight;
				parent[c] = node;
			}
		}
	}
}

void Graph_2::printParent(int of) const
{
	if (parent[of] == (-1)) {
		print << " " << of;
		return;
	}

	printParent(parent[of]);

	print << " " << of;
}

uint32 Graph_2::getShortestPathNode(std::vector<bool> isFinal) const
{
	uint32 minDist = -1;
	uint32 minIdx = 0;

	for (int i = 0; i < V; i++) {
		if (minDistance[i] < minDist && isFinal[i] == false) {
			minDist = minDistance[i];
			minIdx = i;
		}
	}
	return minIdx;
}

void Graph_2::initGraphMatrixWeight()
{
	std::ifstream fl; /* read graph data from file */
	fl.open("graph_data.txt", std::ios_base::in);

	uint32 w; /* variable that hold edge weight */

	fl >> V; /* get number of vertices */

			 /* initialize graph with V number of forward list, to hold every vertex neighbors */
	graph.assign(V, std::forward_list<AdjacentNode>());

	/* initialize parent vector with -1 ("no parent") */
	parent.assign(V, -1);

	/* initialize minDistance vector with infinit value (-1 for unsigned integer is the maximum value) */
	minDistance.assign(V, -1);

	/* read graph links between vertices */
	for (int i = 0; i < V*V; i++) {
		fl >> w;
		if (w != 0) {
			/* if weight w!=0, means that there is a link between this two nodes
			if matrix is iterate as a vector, element x is at position : row = x / b, col = x % b
			*/
			graph[i / V].push_front(AdjacentNode(i / V, i%V, w));
		}
	}

	fl.close();
}

Graph_2::Graph_2()
{
}

Graph_2::~Graph_2()
{
}

void Graph_2::initGraph()
{
	initGraphMatrixWeight();
}

void Graph_2::shortestPath(uint32 src, uint32 dst)
{
	dijkstra(src);

	print << "\n\nVertex     Distance      Path";
	print << "\n" << std::setw(3) << src << "->" << dst << "       " << minDistance[dst] << "        ";
	printParent(dst);
}

void Graph_2::shortestPath(uint32 src)
{
	dijkstra(src);

	print << "\n\nVertex     Distance      Path";
	for (int i = 0; i < V; i++) {
		if (i == src)
			continue;
		print << "\n" << std::setw(3) << src << "->" << std::setw(3) << i << "       " << std::setw(3) << minDistance[i] << "        ";
		printParent(i);
	}
}

void Graph_2::everyAdjacent() const
{
	if (!V)
		return;

	for (size_t i = 0; i < V; i++)
	{
		print << "\nAdjacent of " << i << ": ";
		for (AdjacentNode to : graph[i]) {
			print << "\n  - to " << std::setw(3) << std::left << to.child << ", distance " << to.weight;
		}
		print << eol;
	}
}

void Graph_2::clear() {
	if (graph.size()) {
		for (size_t i = 0; i < graph.size(); i++)
		{
			graph[i].clear(); /* clear every forward_list in graph */
		}
		graph.clear();
		V = 0;
		from = -1;
		to = -1;
	}
}

void test_Graph_2() {
	Graph_2 g;
	g.initGraph();
	
	g.shortestPath(7, 10);

	getchar();
}