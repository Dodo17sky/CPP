#include "stdafx.h"
#include "Graph_3.h"
#include <fstream>
#include <iomanip>
#include <string>
#include <algorithm>

Graph_3::Graph_3()
{
	info;
}

Graph_3::Graph_3(std::vector<std::vector<char>> initData, int rows, int cols):
	data(initData),
	R(rows),
	C(cols)
{
	createGraph();
}

Graph_3::~Graph_3()
{
}

void Graph_3::dijkstra(int src)
{
	std::vector<bool> isFinal(V, false);
	parent.assign(V, -1);
	minDistance.assign(V, -1);

	if (src >= V)
		return;

	/* initialize source node */
	parent[src] = -1;
	minDistance[src] = 0;

	for (int i = 0; i < (V - 1); i++) {
		uint32 m = getShortestPathNode(isFinal);

		isFinal[m] = true;

		for (AdjacentNode to : graph[m]) {
			if (isFinal[to.child] == false && minDistance[m] + to.weight < minDistance[to.child]) {
				parent[to.child] = m;
				minDistance[to.child] = minDistance[m] + to.weight;
			}
		}
	}
}

void Graph_3::printParent(int of) const
{
	if( of == (-1) ) {
		return;
	}

	printParent(parent[of]);

	print << of << " ";
}

uint32 Graph_3::getShortestPathNode(std::vector<bool> isFinal) const
{
	uint32 minDst = -1;
	int    minIdx = 0;

	for (int i = 0; i < V; i++)
	{
		if (minDistance[i] < minDst && isFinal[i] == false) {
			minDst = minDistance[i];
			minIdx = i;
		}
	}

	return minIdx;
}

void Graph_3::initGraph(std::string fileName)
{
	getDataFromFile(fileName);
	createGraph();
}

void Graph_3::getDataFromFile(std::string fileName)
{
	char c;
	std::ifstream fl;

	fl.open(fileName, std::ios_base::in);

	/*  get number of rows and columns */
	fl >> R >> C;

	/* init data matrix */
	data.assign(R, std::vector<char>(C, '#'));

	/* fill in data matrix */
	for (size_t i = 0; i < R*C; i++)
	{
		fl >> c;
		data[i/C][i%C] = c;
	}

	fl.close();
}

void Graph_3::createGraph()
{
	/* set number of verticies */
	V = R * C;

	/* init graph container */
	graph.assign(R*C, std::forward_list<AdjacentNode>());

	for (int i = 0; i < V; i++) {
		// check top node
		if (hasTopNode(i)) {
			addAdjacent(i, getTopNode(i));
		}

		// check right node
		if (hasRightNode(i))
			addAdjacent(i, getRightNode(i));

		// check bottom node
		if (hasBottomNode(i))
			addAdjacent(i, getBottomNode(i));

		// check left node
		if (hasLeftNode(i))
			addAdjacent(i, getLeftNode(i));
	}
}

void Graph_3::p_updateDataPath(int node) {
	if(node == (-1))
		return;

	p_updateDataPath(parent[node]);

	data[node/C][node%C] = '+';
}

void Graph_3::p_printData() const {
	std::string s = std::string(C + 2, '#');
	
	print << s;
	for(auto row : data) {
		print << eol;
		print << "#";
		for(char c : row) {
			print << c;
		}
		print << "#";
	}
	print << eol << s;
}

bool Graph_3::hasTopNode(int n) const {
	n -= C;

	if(n>=0)
		if(data[n/C][n%C]=='.')
			return true;

	return false;
}

bool Graph_3::hasRightNode(int n) const {
	if(n==(V-1))
		return false;

	n += 1;

	if((n%C)!=0)
		if(data[n/C][n%C]=='.')
			return true;

	return false;
}

bool Graph_3::hasBottomNode(int n) const {
	n += C;

	if(n<V)
		if(data[n/C][n%C]=='.')
			return true;

	return false;
}

bool Graph_3::hasLeftNode(int n) const {
	if(n==0)
		return false;
	
	n -= 1;

	if((n%C)!=(C-1))
		if(data[n/C][n%C]=='.')
			return true;

	return false;
}

uint32 Graph_3::getTopNode(uint32 n) const {
	return n-C;
}

uint32 Graph_3::getRightNode(uint32 n) const {
	return n+1;
}

uint32 Graph_3::getBottomNode(uint32 n) const {
	return n+C;
}

uint32 Graph_3::getLeftNode(uint32 n) const {
	return n-1;
}

void Graph_3::addAdjacent(uint32 parent, uint32 child) {
	graph[parent].push_front(AdjacentNode(parent, child, 1));
}

void Graph_3::initGraph()
{
	const std::string file = "drawed_map.txt";

	initGraph(file);
}

void Graph_3::printShortestPath(uint32 src, uint32 dst) {
	dijkstra(src);

	if (minDistance[dst] == (-1)) {
		return;
	}

	for (std::vector<char>& row : data) {
		std::replace(row.begin(), row.end(), '.', ' ');
	}

	p_updateDataPath(dst);
	p_printData();
}

void Graph_3::shortestPath(uint32 src, uint32 dst)
{
	dijkstra(src);

	if (minDistance[dst] == (-1)) {
		print << eol << eol << "No path from " << src << " to " << dst << eol;
		return;
	}

	print << "\nRute: " << src << "->" << dst << eol;
	print << "Distance: " << minDistance[dst] << eol;
	print << "Path: ";
	printParent(dst);
}

void Graph_3::shortestPath(uint32 src)
{
	info;

}

void Graph_3::everyAdjacent() const
{
	for (int i = 0; i < V; i++) {
		print << "\nAdjacent of " << std::setw(3) << std::left << i << ": ";
		for (AdjacentNode to : graph[i]) {
			print << to.child << " ";
		}
	}
}

void Graph_3::clear()
{
	info;

}

std::vector<std::vector<char>> Graph_3::getData() const
{
	return data;
}

void test_Graph_3()
{
	std::vector<std::vector<char>> data;
	Graph_3 g;
	g.initGraph();

	int f = 10, t = 365;

	for (int i = 0; i < 6; i++) {
		g.shortestPath(f, t);
		
		t -= 40;
		data = g.getData();
		data.pop_back();
		data.pop_back();

		g = Graph_3(data, data.size(), data[0].size());
	}
	
}
