#include "stdafx.h"
#include "Graph_1.h"

#include <fstream>
#include <iomanip>

Graph_1::Graph_1(void)
{
}

Graph_1::~Graph_1(void)
{
}

uint32 Graph_1::minDistance(std::vector<uint32> dist, std::vector<bool> included) const {
	uint32 min		= -1;
	uint32 minIdx	= 0;

	for(uint32 v = 0; v < V; v++) {
		if(included[v]==false && dist[v] < min)
			min = dist[v], minIdx = v;
	}

	return minIdx;
}

void Graph_1::printParent(int dst) const {
	if(parent[dst] == (-1))
		return;

	printParent(parent[dst]);

	print << " - " << dst;
}

void Graph_1::printPath(int src, int dst) const
{
	if (src == dst)
		return;

	if (distance[dst] == (-1)) {
		print << "\n" << src << "->" << std::setw(3) << std::left << dst << "    " << "inf";
	}
	else {
		print << "\n" << src << "->" << std::setw(3) << std::left << dst << "    " << std::setw(3) << std::left << distance[dst] << "           " << src;
		printParent(dst);
	}
}

void Graph_1::initGraph() {
	std::ifstream fl;
	fl.open("graph_data.txt", std::ios_base::in);

	fl >> V;

	graph = std::vector<std::vector<int>>(V);
	distance = std::vector<uint32>(V);
	parent = std::vector<int>(V);

	for(int i = 0; i < V; i++ ) {
		graph[i] = std::vector<int>(V);
	}

	for(int i = 0; i < V*V; i++) {
		fl >> graph[i/V][i%V];
	}

	fl.close();
}

void Graph_1::printAdjacent() const {
	print << eol;
	for(int i = 0; i < V; i++) {
		print << "Adjacent for " << i << ": ";
		for( int j = 0; j < V; j++ ) {
			if(graph[i][j])
				print << j << " ";
		}
		print << eol;
	}
}

void Graph_1::dijkstra(int src) {
	// Funtion that implements Dijkstra's single source shortest path
	// algorithm for a graph represented using adjacency matrix
	// representation

	/*  isPart[i] is true if vertex i is included in the shortest path from src */
	std::vector<bool> isFinal(V);

	parent[src] = -1;

	/* initialize all distance as infinite and isPart as false  */
	for(int i = 0; i < V; i++) {
		distance[i] = -1;
		isFinal[i] = false;
	}

	/* distance from src to src is always 0  */
	distance[src] = 0;

	/*  Find shortest path for all vertices  */
	for(int count = 0; count < V-1; count++) {
		/*  Pick the minimum distance vertex from the set of vertices not yet processed. 
		    idx is always equal to src in first iteration
		*/
		uint32 reach = minDistance(distance, isFinal);

		/*  mark the picked vertex as processed  */
		isFinal[reach] = true;

		for(uint32 v = 0; v < V; v++) {
			if( isFinal[v]==false && graph[reach][v] && distance[reach] + graph[reach][v] < distance[v] ) {
				parent[v] = reach;
				distance[v] = distance[reach] + graph[reach][v]; 
			}
		}
	}
}

bool Graph_1::isDirected() const
{
	for (size_t i = 0; i < V; i++)
	{
		for (size_t j = 0; j < V; j++)
		{
			if (graph[i][j] != graph[j][i]) {
				print << "\nGraph is directed: \n\t"
					<< i << "-" << j << " = " << graph[i][j] << "\n\t"
					<< j << "-" << i << " = " << graph[j][i] << "\n";
				return true;
			}
		}
	}
	print << "\nGraph is undirected\n";
	return false;
}

void Graph_1::shortestPath(int src, int dst)
{
	dijkstra(src);

	print << "\nVertex  Distance    Path";
	printPath(src, dst);
}

void Graph_1::shortestPath(int src)
{
	dijkstra(src);

	print << "\nVertex  Distance    Path";

	for(int i = 0; i < V; i++)
		printPath(src, i);
}

void test_Graph_1() {
	Graph_1 g;
	g.initGraph();
	g.printAdjacent();
	g.isDirected();
	
	while (true) {
		int src, dst;
		system("cls");
		print << "Check nodes: ";

		std::cin >> src >> dst;
		std::cin.ignore();

		if (src == 99)
			break;

		g.shortestPath(src, dst);
		
		getchar();
	}

	getchar();
}