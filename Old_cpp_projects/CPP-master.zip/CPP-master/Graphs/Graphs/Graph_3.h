#pragma once

#include <iostream>
#include <vector>
#include <forward_list>

typedef unsigned int	uint32;
#define print			std::cout
#define eol				std::endl
#define info			print << __FUNCTION__

void test_Graph_3();

class Graph_3
{
	struct AdjacentNode {
		uint32 parent;
		uint32 child;
		uint32 weight;

		AdjacentNode(uint32 p, uint32 c, uint32 w) : parent(p), child(c), weight(w) {}
	};
	int V, R, C;
	std::vector<std::forward_list<AdjacentNode>> graph;
	std::vector<int> parent;
	std::vector<uint32> minDistance;
	std::vector<std::vector<char>> data;

	void dijkstra(int src);
	void printParent(int of) const;
	uint32 getShortestPathNode(std::vector<bool> isFinal) const;
	void initGraph(std::string fileName);
	void getDataFromFile(std::string fileName);
	void createGraph();
	void p_updateDataPath(int node);
	void p_printData() const;
	bool hasTopNode(int n) const;
	bool hasRightNode(int n) const;
	bool hasBottomNode(int n) const;
	bool hasLeftNode(int n) const;
	uint32 getTopNode(uint32 n) const;
	uint32 getRightNode(uint32 n) const;
	uint32 getBottomNode(uint32 n) const;
	uint32 getLeftNode(uint32 n) const;
	void addAdjacent(uint32 parent, uint32 child);

public:
	Graph_3();
	Graph_3(std::vector<std::vector<char>> initData, int rows, int cols);
	~Graph_3();
	void initGraph();
	void printShortestPath(uint32 src, uint32 dst);
	void shortestPath(uint32 src, uint32 dst);
	void shortestPath(uint32 src);
	void everyAdjacent() const;
	void clear();

	std::vector<std::vector<char>> getData() const;
};
