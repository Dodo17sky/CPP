#pragma once

#include <iostream>
#include <vector>
#include <forward_list>

typedef unsigned int	uint32;
#define print			std::cout
#define eol				std::endl
#define info			print << __FUNCTION__

void test_Graph_2();

class Graph_2
{
	struct AdjacentNode {
		uint32 parent;
		uint32 child;
		uint32 weight;

		AdjacentNode(uint32 p, uint32 c, uint32 w) : parent(p), child(c), weight(w) {}
	};

	uint32 from, to;
	uint32 V;
	std::vector<std::forward_list<AdjacentNode>> graph;
	std::vector<int> parent;
	std::vector<uint32> minDistance;

	void dijkstra(int src);
	void printParent(int of) const;
	uint32 getShortestPathNode(std::vector<bool> isFinal) const;
	void initGraphMatrixWeight();

public:
	Graph_2();
	~Graph_2();
	void initGraph();
	void shortestPath(uint32 src, uint32 dst);
	void shortestPath(uint32 src);
	void everyAdjacent() const;
	void clear();
};

