#pragma once

#include <iostream>
#include <vector>

typedef unsigned int	uint32;
#define print			std::cout
#define eol				std::endl

void test_Graph_1();

class Graph_1
{
	uint32 V;
	std::vector<std::vector<int>> graph;
	std::vector<uint32> distance;
	std::vector<int> parent;

	void   dijkstra(int src);
	uint32 minDistance(std::vector<uint32> dist, std::vector<bool> included) const;
	void   printParent(int dst) const;
	void   printPath(int src, int dst) const;

public:
	Graph_1(void);
	~Graph_1(void);

	void initGraph();
	void printAdjacent() const;
	bool isDirected() const;
	void shortestPath(int src, int dst);
	void shortestPath(int src);
};

