#include "stdafx.h"
#include "PathFinder.h"
#include <iomanip>

#define print		std::cout
#define eol			std::endl

PathFinder::PathFinder()
{
}


PathFinder::~PathFinder()
{
}

void PathFinder::getData(std::string file)
{
	char tmp;
	std::ifstream fl;
	fl.open(file, std::ios_base::in);
	
	fl >> height >> width;

	map = new char*[height];
	for (int i = 0; i < height; i++)
		map[i] = new char[width];

	unsigned int all = width * height;
	for (int i = 0; i < all; i++) {
		fl >> tmp;
		if (tmp == 'F') {
			xF = i % width;
			yF = i / width;
		}
		if (tmp == 'T') {
			xT = i % width;
			yT = i / width;
		}
		map[i/width][i%width] = tmp;
	}

	fl.close();
}

void PathFinder::printData() const
{
	print << eol << eol;
	for (size_t i = 0; i < height; i++)
	{
		for (size_t j = 0; j < width; j++)
		{
			print << std::setw(3) << map[i][j];
		}
		print << eol << eol;
	}

	print << "From " << xF << "-" << yF << " to " << xT << "-" << yT << eol;
}

void test_PathFinder(){

	PathFinder pf;
	pf.getData("path_finder_data.txt");
	pf.printData();

	getchar();
}