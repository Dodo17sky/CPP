#include "stdafx.h"
#include "Graph.h"

Graph::Graph(int len):
	m_length(len)
{
	if (len) {
		m_data = std::vector<std::list<Edge>>(len);
	}
}

Graph::~Graph()
{
}

void Graph::addVertex(int id)
{
	if (id != m_length) {
		std::cout << "You try to add vertex " << id << " but next one should be " << m_length << "\n";
		return;
	}

	m_data.push_back(std::list<Edge>());
	m_length++;
}

void Graph::addEdge(int a, int b, int weight)
{
	if (a >= m_length || b >= m_length) {
		// Trying to connect vertices that not exist
		return;
	}

	Edge e;
	e.weight = weight;

	e.from = a;
	e.to = b;
	m_data[a].push_back(e);

	e.from = b;
	e.to = a;
	m_data[b].push_back(e);
}

void Graph::printInfo() const
{
	if (!m_length)
		return;

	std::cout << "\n  Graph info\n\n";

	for (int i=0; i<m_length; i++) {
		print << " - Neighbors for " << i << ": ";
		for (Edge neighbor : m_data[i]) {
			std::cout << neighbor.to << " ";
		}
		std::cout << "\n";
	}
}

void Graph::print_DFS() const {
	bool* visited = new bool[m_length];
	int node;
	std::stack<int> toCheck;

	if (!m_length)
		return;

	std::fill(visited, visited + m_length, false);

	node = m_data[0].front().from;
	toCheck.push(node);
	visited[node] = true;

	print << "\n  Graph DFS: " << toChar(node) << " ";
	
	while (true) {
		if (visited[m_data[node].back().to] == true) {
			// For this node, even the last neighbor is visited
			// There is no other neighbor to visit. Do: stack.pop()
			toCheck.pop();

			if (toCheck.size() == 0) {
				// Stack is empty. There is no other node to visit in all graph.
				// Break the loop
				break;
			}
			node = toCheck.top();
		}

		for (Edge neighbor : m_data[node]) {
			if (visited[neighbor.to] == false) {
				node = neighbor.to;
				print << toChar(node) << " ";
				toCheck.push(node);
				visited[node] = true;
				break;
			}
		}
	}

	delete[] visited;
}

void Graph::print_BFS() const
{
	bool* visited = new bool[m_length];
	int node;
	std::queue<int> toCheck;

	if (m_length == 0)
		return;

	std::fill(visited, visited + m_length, false);

	node = m_data[0].front().from;
	print << "\n  Graph BFS: " << toChar(node) << " ";
	toCheck.push(node);
	visited[node] = true;

	while (true) {
		if (toCheck.size() == 0)
			break;

		node = toCheck.front();

		for (Edge neighbor : m_data[node]) {
			if(visited[neighbor.to]==false) {
				print << toChar(neighbor.to) << " ";
				visited[neighbor.to] = true;
				toCheck.push(neighbor.to);
			}
		}
		toCheck.pop();
	}
}

void Graph::shortestPathFrom(int node) const
{
	std::vector<bool> isEnded = std::vector<bool>(m_length, false);
	std::vector<unsigned int> paths = std::vector<unsigned int>(m_length);

	std::fill(paths.begin(), paths.end(), std::numeric_limits<unsigned int>::max());

	print << "\n\nShortest path from " << node << ": \n";

	paths[node] = 0;
	isEnded[node] = true;

	for (int i = 0; i < m_length; i++) {
		for (Edge link : m_data[node]) {
			paths[link.to] = std::min(paths[link.to], paths[node] + link.weight);
		}
		unsigned int shortest = -1;
		for (int i = 0; i < m_length; i++) {
			if (paths[i] < shortest && isEnded[i] == false) {
				shortest = paths[i];
				node = i;
			}
		}
		isEnded[node] = true;
	}

	for (size_t i = 0; i < paths.size(); i++)
	{
		print << " - to " << i << ": " << paths[i] << "\n";
	}
}

void test_Graph1()
{
	/*
	Graph g(8);
	g.addEdge(0, 2);
	g.addEdge(0, 3);
	g.addEdge(0, 6);
	g.addEdge(1, 2);
	g.addEdge(1, 3);
	g.addEdge(1, 5);
	g.addEdge(4, 2);
	g.addEdge(2, 5);
	g.addEdge(3, 5);
	g.addEdge(4, 5);
	g.addEdge(6, 7);
	g.printInfo();
	g.print_DFS();
	g.print_BFS();
	*/

	/*
	Graph g(8);
	g.addEdge(0, 1, 8);
	g.addEdge(0, 3, 7);
	g.addEdge(0, 6, 19);
	g.addEdge(1, 4, 11);
	g.addEdge(1, 5, 21);
	g.addEdge(2, 5, 20);
	g.addEdge(2, 7, 15);
	g.addEdge(3, 5, 3);
	g.addEdge(4, 6, 2);
	g.print_DFS();
	g.print_BFS();
	g.shortestPathFrom(0);
	*/



	getchar();
}