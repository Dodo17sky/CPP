#pragma once
#include <string>
#include <iostream>
#include <fstream>

void test_PathFinder();

class PathFinder
{
	unsigned int width;
	unsigned int height;
	char** map;

	int xF, yF, xT, yT;

public:
	PathFinder();
	~PathFinder();

	void getData(std::string file);
	void printData() const;
};

