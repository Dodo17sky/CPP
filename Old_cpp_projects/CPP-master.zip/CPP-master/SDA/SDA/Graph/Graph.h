#pragma once

#include <vector>
#include <string>
#include <list>
#include <iostream>
#include <stack>
#include <queue>
#include <algorithm>
#include <math.h>

#define print		std::cout
#define eol			std::endl
#define toChar(x)   ((char)(x+'A'))

void test_Graph1();

typedef struct EdgeStructure {
	int from;
	int to;
	unsigned int weight;
} Edge;

class Graph
{
	int m_length;
	std::vector<std::list<Edge>> m_data;

public:
	Graph(int len = 0);
	~Graph();

	void addVertex(int id);
	void addEdge(int from, int to, int weight);
	void printInfo() const;
	void print_DFS() const;
	void print_BFS() const;
	void shortestPathFrom(int node) const;
};
