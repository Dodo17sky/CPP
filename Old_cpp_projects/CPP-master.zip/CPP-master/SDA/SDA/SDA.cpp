// SDA.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Tree\BinaryTree.h"
#include "Graph\Graph.h"
#include "Graph\PathFinder.h"

int main()
{
	// test_BinaryTree();
	
	// test_Graph1();

	test_PathFinder()

    return 0;
}

