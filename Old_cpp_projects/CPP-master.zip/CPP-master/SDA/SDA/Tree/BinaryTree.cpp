#include "stdafx.h"
#include "BinaryTree.h"

#include <time.h>
#include <fstream>
#include <chrono>

int objN = 0;
int objD = 0;

#define O_NEW(type) new type; objN++
#define O_DEL(obj) delete obj; objD++

BinaryTree::BinaryTree()
{
	root = NULL;
}

BinaryTree::~BinaryTree()
{
	clear();
}

void BinaryTree::clear()
{
	p_clear(root);
}

void BinaryTree::insert(int value)
{
	if (root != NULL) {
		p_insert(value, root);
	}
	else {
		root = O_NEW(Node(value));
	}
}

void BinaryTree::insert_nr(int value)
{
	if (root != NULL) {
		p_insert_nr(value, root);
	}
	else {
		root = O_NEW(Node(value));
	}
}

void BinaryTree::print(BinaryTree::ORDER order) const
{
	p_print(root, order);
}

Node BinaryTree::min()
{
	cycles = 0;
	Node n = p_min(root);
	std::cout << "\n\t Minimum method cycles: " << cycles << "\n\n";
	return n;
}

Node BinaryTree::max()
{
	cycles = 0;
	Node n = p_max(root);
	std::cout << "\n\t Maximum method cycles: " << cycles << "\n\n";
	return n;
}

bool BinaryTree::isEmpty() const
{
	return (root == NULL);
}

unsigned int BinaryTree::countItems()
{
	return p_count(root);
}

unsigned int BinaryTree::countLeaf()
{
	return p_countLeaf(root);
}

unsigned int BinaryTree::countRootNodes()
{
	return p_countRootNodes(root);
}

unsigned int BinaryTree::high()
{
	return p_high(root);
}

void BinaryTree::toGraphicView()
{
	p_toGraphicView(root);
}

void BinaryTree::p_clear(PNode& node)
{
	if (node != NULL) {
		p_clear(node->left);
		p_clear(node->right);
		O_DEL(node);
		node = NULL;
	}
}

void BinaryTree::p_insert(int value, PNode node)
{
	if (value < node->data) {
		if (node->left == NULL) {
			node->left = O_NEW(Node(value));
		}
		else {
			p_insert(value, node->left);
		}
	}
	else {
		if (node->right == NULL) {
			node->right = O_NEW(Node(value));
		}
		else {
			p_insert(value, node->right);
		}
	}
}

void BinaryTree::p_insert_nr(int value, PNode node)
{
	PNode aux = node;
	while (true) {
		if (!aux)
			break;

		if (value < aux->data) {
			if(aux->left)
				aux = aux->left;
			else {
				PNode newNode = O_NEW(Node(value));
				aux->left = newNode;
				break;
			}
		}
		else {
			if (aux->right) {
				aux = aux->right;
			}
			else {
				PNode newNode = O_NEW(Node(value));
				aux->right = newNode;
				break;
			}
		}
	}
}

void BinaryTree::p_print(PNode node, BinaryTree::ORDER order) const
{
	switch (order)
	{
	case BinaryTree::inorder:
		p_printInorder(node);
		break;
	case BinaryTree::deorder:
		p_printDeorder(node);
		break;
	case BinaryTree::preorder:
		p_printPreorder(node);
		break;
	case BinaryTree::postorder:
		p_printPostorder(node);
		break;
	default:
		break;
	}
}

void BinaryTree::p_printInorder(PNode node) const
{
	if (node != NULL) {
		p_printInorder(node->left);
		std::cout << node->data << " ";
		p_printInorder(node->right);
	}
}

void BinaryTree::p_printDeorder(PNode node) const
{
	if (node != NULL) {
		p_printDeorder(node->right);
		std::cout << node->data << " ";
		p_printDeorder(node->left);
	}
}

void BinaryTree::p_printPreorder(PNode node) const
{
	if (node != NULL) {
		std::cout << node->data << " ";
		p_printPreorder(node->left);
		p_printPreorder(node->right);
	}
}

void BinaryTree::p_printPostorder(PNode node) const
{
	if (node != NULL) {
		p_printPreorder(node->left);
		p_printPreorder(node->right);
		std::cout << node->data << " ";
	}
}

Node BinaryTree::p_min(PNode node)
{
	cycles++;
	
	//node->friendlyPrint();

	if (node->left == NULL)
		return *node;
	else
		return p_min(node->left);
}

Node BinaryTree::p_max(PNode node)
{
	cycles++;
	
	//node->friendlyPrint();

	if (node->right == NULL)
		return *node;
	else
		return p_max(node->right);
}

unsigned int BinaryTree::p_count(PNode node)
{
	if (node == NULL)
		return 0;
	else {
		return 1 + p_count(node->left) + p_count(node->right);
	}
}

unsigned int BinaryTree::p_countLeaf(PNode node)
{
	if (node == NULL)
		return 0;
	if (node->haveChildren())
		return p_countLeaf(node->left) + p_countLeaf(node->right);
	else
		return 1;
}

unsigned int BinaryTree::p_countRootNodes(PNode node)
{
	if (node == NULL)
		return 0;
	if (node->haveChildren())
		return 1 + p_countRootNodes(node->left) + p_countRootNodes(node->right);
	else
		return 0;
}

unsigned int BinaryTree::p_high(PNode node)
{
	if (node == NULL)
		return 0;
	int leftHigh  = p_high(node->left);
	int rightHigh = p_high(node->right);

	return std::max(leftHigh, rightHigh) + 1;
}

void BinaryTree::p_toGraphicView(PNode node)
{
	int rectHeight = p_high(node);
	int rectWidth = pow(2, rectHeight);

	p_initFill(levels, rectWidth, rectHeight, "----");

	p_printTreeLevelForm(root, rectHeight - 1, pow(2, rectHeight - 1) - 1);

	std::ofstream file;
	file.open("tree.txt", std::ios_base::out);

	for (std::vector<std::string>::reverse_iterator it = levels.rbegin(); it != levels.rend(); it++) {
		file << *it << std::endl;
	}

	file.close();
}

void BinaryTree::p_printTreeLevelForm(PNode node, int lev, int off)
{
	if (node == NULL)
		return;
	else
		std::cout << "L=" << lev << " off=" << off << std::endl;

	p_drawNode(off, lev, node->data);

	lev--;
	p_printTreeLevelForm(node->left, lev, off - pow(2, lev));
	p_printTreeLevelForm(node->right, lev, off + pow(2, lev));
}

void BinaryTree::p_initFill(std::vector<std::string>& v, int width, int height, std::string with)
{
	std::string line;
	line.reserve(with.length()*width);

	while (width--)
		line += with;

	v.clear();
	v = std::vector<std::string>(height*2, line);
}

void BinaryTree::p_drawNode(int x, int y, int value)
{
	if (y >= levels.size())
		return;

	std::string& line = levels[y*2+1];
	std::string nodeVal = std::to_string(value);

	if (nodeVal.length() > 4)
		return;
	
	line.replace(x * 4, nodeVal.length(), nodeVal);
}

void Node::friendlyPrint() const
{
	std::cout << "\n";
	std::cout << "+-------------------------+\n";
	std::cout << "|          " << std::setw(5) << data << "          |\n";
	std::cout << "|        /       \\        |\n";
	std::cout << "|       /         \\       |\n";
	std::cout << "|     ";
	
	if (left)
		std::cout << std::setw(5) << left->data << "      ";
	else
		std::cout << " null      ";

	if (right)
		std::cout << std::setw(5) << right->data << "    |\n";
	else
		std::cout << " null    |\n";

	std::cout << "+-------------------------+\n";
}

bool Node::haveChildren() const
{
	return (left || right);
}

void test_BinaryTree()
{
	{ // b life-cycle start
		BinaryTree b;
		std::srand(time(NULL));

		/*
		 *   Populate tree with items
		 */
		for (int i = 0; i < 10; i++) {
			int item = std::rand() % 1000;
			b.insert_nr(item);
		}
		std::cout << "\n\n";

		/*
		**  Print tree item in increasing and decreasing order
		**/
		//std::cout << "\nInorder: "; b.print(BinaryTree::inorder); std::cout << std::endl;
		//std::cout << "\nDeorder: "; b.print(BinaryTree::deorder); std::cout << std::endl << std::endl;

		/*
		**  Check if tree has no item
		**/
		Node n;
		if (b.isEmpty())
			return;

		/*
		**  Print minimum item in tree
		**/
		n = b.min();
		std::cout << "Minimum item: " << n.data << "\n";

		/*
		**  Print maximum item in tree
		**/
		n = b.max();
		std::cout << "Maximum item: " << n.data << "\n";

		/*
		**  Print number of: items, leaf, nodes
		**/
		std::cout << "Tree has " << b.countItems() << " items\n";
		std::cout << "Tree has " << b.countLeaf() << " leaf\n";
		std::cout << "Tree has " << b.countRootNodes() << " nodes\n";

		/*
		**  Print tree depth
		**/
		std::cout << "Tree high: " << b.high() << "\n";

		/*
		**  Print tree form
		**/
		b.toGraphicView();

	} // b life-cycle end

	std::cout << "\n\nObjects created: " << objN << std::endl;
	std::cout << "Objects deleted: " << objD << std::endl;

	getchar();
}

void test_Recursive_vs_NonRecursive()
{
	BinaryTree b;

	std::srand(time(NULL));

	for (int k = 1000; k < 100000; k += 10000) {
		b.clear();
		std::chrono::high_resolution_clock::time_point start1 = std::chrono::high_resolution_clock::now();
		for (int i = 0; i < k; i++) {
			int item = std::rand() % 1000;
			b.insert_nr(item);
		}
		std::chrono::high_resolution_clock::time_point end1 = std::chrono::high_resolution_clock::now();
		long t1 = std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1).count();
		//std::cout << "Time insert no recursive: " << std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1).count() << " us\n";

		b.clear();

		std::chrono::high_resolution_clock::time_point start2 = std::chrono::high_resolution_clock::now();
		for (int i = 0; i < k; i++) {
			int item = std::rand() % 1000;
			b.insert(item);
		}
		std::chrono::high_resolution_clock::time_point end2 = std::chrono::high_resolution_clock::now();
		long t2 = std::chrono::duration_cast<std::chrono::microseconds>(end2 - start2).count();

		int ratio = (int)(((double)t1 / t2) * 100);
		std::cout << "Ratio " << std::setw(6) << k << ": " << ratio << " : " << t1 << " - " << t2 << std::endl;
		//std::cout << "Time insert recursive  : " << std::chrono::duration_cast<std::chrono::microseconds>(end2 - start2).count() << " us\n";

	}
}
