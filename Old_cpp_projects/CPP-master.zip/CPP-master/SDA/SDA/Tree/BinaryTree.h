#pragma once

#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <string>

void test_BinaryTree();
void test_Recursive_vs_NonRecursive();

class Node;
typedef Node* PNode;

class Node {
public:
	Node(int value = 0) : data(value), left(NULL), right(NULL) {}
	void friendlyPrint() const;
	bool haveChildren() const;

	int data;
	PNode left;
	PNode right;
};

class BinaryTree
{
public:
	BinaryTree();
	~BinaryTree();

	enum ORDER { inorder, preorder, postorder, deorder };

	void clear();
	void insert(int value);
	void insert_nr(int value);
	void print(BinaryTree::ORDER order) const;
	Node min();
	Node max();
	bool isEmpty() const;
	unsigned int countItems();
	unsigned int countLeaf();
	unsigned int countRootNodes();
	unsigned int high();
	void toGraphicView();

private:
	void p_clear(PNode& node);
	void p_insert(int value, PNode node);
	void p_insert_nr(int value, PNode node);
	void p_print(PNode node, BinaryTree::ORDER order) const;
	void p_printInorder(PNode node) const;
	void p_printDeorder(PNode node) const;
	void p_printPreorder(PNode node) const;
	void p_printPostorder(PNode node) const;
	Node p_min(PNode node);
	Node p_max(PNode node);
	unsigned int p_count(PNode node);
	unsigned int p_countLeaf(PNode node);
	unsigned int p_countRootNodes(PNode node);
	unsigned int p_high(PNode node);
	void p_toGraphicView(PNode node);
	void p_printTreeLevelForm(PNode node, int lev, int off);

	void p_initFill(std::vector<std::string>& v, int width, int height, std::string with);
	void p_drawNode(int x, int y, int value);

	PNode root;
	unsigned int cycles;
	std::vector<std::string> levels;
};

